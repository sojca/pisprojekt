package org.pis.services;

import org.pis.entity.Activity;

import javax.ejb.Stateless;

@Stateless
public class ActivityService extends CrudService<Activity> {
}
