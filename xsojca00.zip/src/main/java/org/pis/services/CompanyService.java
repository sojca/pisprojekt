package org.pis.services;

import org.pis.entity.Company;

import javax.ejb.Stateless;

@Stateless
public class CompanyService extends CrudService<Company> {
}
