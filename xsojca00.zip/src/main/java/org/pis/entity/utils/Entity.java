package org.pis.entity.utils;

public class Entity {
}
